export class TranslateConcatData {
  desc: string;
  category: string;
}
