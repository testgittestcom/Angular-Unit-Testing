export const environment = {
  production: true,
  applicationVersion : '{application.version}',
  wolWebServiceBaseUrl : '/witsonline/witswebservice'
};
