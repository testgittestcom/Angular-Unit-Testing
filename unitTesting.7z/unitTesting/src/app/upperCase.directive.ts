import { AfterContentInit } from '@angular/core';
import { Directive } from '@angular/core';
import { ElementRef } from '@angular/core';
import { OnChanges } from '@angular/core';
import { OnDestroy } from '@angular/core';
import { SimpleChanges } from '@angular/core';
import { Component, Input } from '@angular/core';

@Directive({
    selector: '[UpperCase]',
    host: {
       '(input)': 'toUpperCase($event.target.value)',

    }

   })
   export class UpperCaseTextDirective  {

   @Input('UpperCase') allowUpperCase: boolean;
   constructor(private ref: ElementRef) {
   }

   toUpperCase(value: any) {
       if (this.allowUpperCase) {
       this.ref.nativeElement.value = value.toUpperCase();
       }
   }

   }
