
export class dropdown {
  constructor(public id: string, public name: string) { }
}
