import { AfterContentInit } from '@angular/core';
import { Directive } from '@angular/core';
import { ElementRef } from '@angular/core';
import { OnChanges } from '@angular/core';
import { OnDestroy } from '@angular/core';
import { SimpleChanges } from '@angular/core';
import { Component, Input, HostListener } from '@angular/core';
//  import {MAT_MOMENT_DATE_FORMATS, MomentDateAdapter} from '@angular/material-moment-adapter';
//  import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';
@Directive({
  selector: '[OnlyNumber]',
  host: {
       '(input)': 'repairdate($event.target.value)',

    },
  //   providers: [
  //    {provide: MAT_DATE_LOCALE, useValue: 'fr'},
  //    {provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE]},
  //    {provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS},
  //  ],
})
export class RepairDateDirective {
  inputValue = [];
  dateformat: DateFormat = new DateFormat();
  // private adapter: DateAdapter<any>,
  constructor(private el: ElementRef) { }
  @Input() OnlyNumber: boolean;


  @HostListener('dateChange', ['$event']) onKeyDown(event) {
    // this.adapter.setLocale('fr');
    const date = new Date(event.value);
    const year = date.getFullYear().toString().substr(-2);
    let month: any = date.getMonth() + 1;
    let day: any = date.getDate();
    if (month < 10 ) {
       month = '0' + month.toString();
    }
    if (day < 10) {

       day = '0' + day.toString();

    }
      this.el.nativeElement.value = year + '/' + month + '/' + day;
    }
}

export class DateFormat {
  year: string;
  month: string;
  day: string;
}
