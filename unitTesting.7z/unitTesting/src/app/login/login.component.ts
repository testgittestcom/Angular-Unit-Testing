import { Component, OnInit, ElementRef, HostListener, Inject, Input, Output, AfterContentInit, ContentChild, AfterViewInit, ViewChild, ViewChildren, Renderer2} from '@angular/core';


import { FormGroup, FormControl, Validators, ReactiveFormsModule} from '@angular/forms';
import { Router, ActivatedRoute, Params, NavigationEnd} from '@angular/router';
import { DataserviceService } from '../dataservice.service';

import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { MatKeyboardModule, MatKeyboardService } from '@ngx-material-keyboard/core';
/*For Material Icon*/
import {DomSanitizer} from '@angular/platform-browser';
import {MatIconRegistry} from '@angular/material';
import { KeyboardComponent } from '../keyboard/keyboard.component';
import { environment } from '../../environments/environment';

@Component({
 selector: 'app-dialog-overview-example-dialog',
 template: `<div class="dialog_btn dialog_box">

<div mat-dialog-content class="text-center dialog_content">
 <span>{{data.error_txt | translate}}</span>
</div>
<div mat-dialog-actions>
<div class="row no-gutters w-100">

 <div class="col-6 pr-1 pl-0 m-auto" *ngIf="data.ok_btn">
 <div class="btn_radius">
               <button type="submit" (click)="onNoClick()"  mat-raised-button color="primary" class="text-uppercase w-100">{{ data.ok_btn_text == null ? 'Ok' : data.ok_btn_text }}</button>
             </div>
   </div>
   <div class="col-6 pl-1 pr-0 m-auto" *ngIf="data.cancel_btn">
   <div class="btn_radius  btn_outlayout">
               <button type="submit" (click)="onNoClick()" mat-raised-button color="primary" class="text-uppercase w-100">Cancel</button>
             </div>
   </div>
 </div>
</div>
</div>`,
})


export class DialogOverviewExampleDialogComponent implements OnInit {
constructor(public renderer: Renderer2,
   public dialogRef: MatDialogRef<DialogOverviewExampleDialogComponent>,
      @Inject(MAT_DIALOG_DATA) public data: any ) {

       }
ngOnInit() {
}
onNoClick(): void {
   this.dialogRef.close();

 }

}


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit, AfterViewInit {

  loginform: FormGroup;
  // @Input('show-modal') showModal: boolean;
  login_status_error = false;
  isSubmitted = false;
  user_details: any = [];
  focus = '';
  dialogRef;
  applicationVersion: string = environment.applicationVersion;

  constructor(public renderer: Renderer2, iconRegistry: MatIconRegistry, sanitizer: DomSanitizer, private router: Router, public service: DataserviceService, public keyboard: KeyboardComponent, public dialog: MatDialog) {
  }
  ngAfterViewInit() {
        this.renderer.selectRootElement('#login_username').focus();

    }
  ngOnInit() {
    localStorage.clear();
   this.service.updateLanguage('en');
  	this.loginform = new FormGroup({
        login_empolyeeid: new FormControl('', Validators.required),
        login_username: new FormControl('', Validators.required),
        login_password: new FormControl('', Validators.required),

    });
  }

  checkForApplicationVersion() {
  	this.service.getApplicationVersion().subscribe( (data: any) => {
      const serverVersion = data.version;
      console.log('Server Version ' + serverVersion);
      console.log('Local Version ' + this.applicationVersion);

      if (serverVersion !== this.applicationVersion) {
        let newVersionDialogRef;
        newVersionDialogRef = this.dialog.open(DialogOverviewExampleDialogComponent,
          { width: '300px',
          data : {
            error_txt: 'New version found, click to update app.',
            ok_btn: true,
            ok_btn_text: 'Update'
          }
        });
        newVersionDialogRef.afterClosed().subscribe(() => {
          console.log('Before refresh of page');
          window.location.reload();
        });
      }
    }, error => {
    	console.log('Error response when calling application version ' + error);
    });
  }

  public openDialog(erroe_txt, focus_id?): void {

   this.dialogRef = this.dialog.open(DialogOverviewExampleDialogComponent, {
     width: '300px',
      data: { error_txt: erroe_txt, cancel_btn: false, ok_btn: true, focus_id: focus_id }
   });
   this.dialogRef.afterClosed().subscribe(popclose => {
      this.renderer.selectRootElement('#' + focus_id).focus();
   });
}
  loginformsubmit() {
     this.isSubmitted = true;
     if (this.loginform.valid) {
        this.service.status('succeess');
        this.service.loginservice(this.loginform.value.login_username, this.loginform.value.login_password).subscribe(
          result => {
                 // let qcFlagData: object;
                 this.isSubmitted = false;
                  this.login_status_error = false;
                  this.user_details = [];
                  this.user_details.push(result);
                  if (this.loginform.value.login_empolyeeid !== '') {
                    this.user_details.forEach(item => {
                      if (item.hasOwnProperty('defaultVpc')) {
                           this.service.check_emplyee(item.defaultVpc.vpcCode, this.loginform.value.login_empolyeeid).subscribe(data => {

                              this.service.check_qc_nonqc(item.defaultVpc.vpcCode, this.loginform.value.login_empolyeeid).subscribe(res => {
                                  this.user_details.push(this.loginform.value);
                                  this.user_details.push({qcFlag: res['qcFlag']});
                                  if (this.loginform.value.login_username === 'MULAF001') {
                                      this.service.updateLanguage('es');
                                      this.user_details.push({lang: 'es'});
                                  } else {
                                    this.service.updateLanguage('en');
                                    this.user_details.push({lang: 'en'});
                                  }
                                   localStorage.setItem('user_details', JSON.stringify(this.user_details));
                                  this.router.navigate(['/home']);
                              });


                           }, error => {
                               this.login_status_error = true;
                               this.openDialog('Employee id not found', 'login_empolyeeid' );
                           });
                      }
                    });
                   } else {
                     this.router.navigate(['/home']);
                   }
          }, error => {
               this.login_status_error = true;
               if ( Number(error.status)  === 0) {
                this.openDialog('System unavailable, try after sometime', 'login_username');
               } else {
             	 this.openDialog('Invalid Username or Password', 'login_username');
               }
          });
     } else {
       this.service.status('error');
     }
  }
}


