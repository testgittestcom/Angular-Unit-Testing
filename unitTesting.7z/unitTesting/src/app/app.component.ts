import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params, NavigationEnd} from '@angular/router';
import {DomSanitizer} from '@angular/platform-browser';
import {MatIconRegistry} from '@angular/material';
import { DataserviceService } from './dataservice.service';
import { TranslateService } from '@ngx-translate/core';
import { TranslateConcatData } from './TranslateTargetInfo';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent  implements OnInit {
  title = 'app';
  islogin = true;

  constructor(public service: DataserviceService, public router: Router, iconRegistry: MatIconRegistry, sanitizer: DomSanitizer, private translate: TranslateService) {
    iconRegistry.addSvgIcon('status_mark',
    sanitizer.bypassSecurityTrustResourceUrl('assets/images/close_mark.svg'));
     iconRegistry.addSvgIcon('prev_arrow',
        sanitizer.bypassSecurityTrustResourceUrl('assets/images/down_arrow.svg'));
     iconRegistry.addSvgIcon('status_hold',
        sanitizer.bypassSecurityTrustResourceUrl('assets/images/status_hold.svg'));
      iconRegistry.addSvgIcon('login-user',
        sanitizer.bypassSecurityTrustResourceUrl('assets/images/login_user.svg'));
    iconRegistry.addSvgIcon('login-password',
        sanitizer.bypassSecurityTrustResourceUrl('assets/images/login_password.svg'));
    iconRegistry.addSvgIcon('login-empid',
        sanitizer.bypassSecurityTrustResourceUrl('assets/images/login_emplyeeid.svg'));
    iconRegistry.addSvgIcon('login-success',
        sanitizer.bypassSecurityTrustResourceUrl('assets/images/login_success.svg'));
    iconRegistry.addSvgIcon('lineal-keyboard',
        sanitizer.bypassSecurityTrustResourceUrl('assets/images/lineal_keyboard.svg'));
    iconRegistry.addSvgIcon('login-error',
        sanitizer.bypassSecurityTrustResourceUrl('assets/images/login_error.svg'));
  }
  ngOnInit() {
  	this.service.getLanguage().subscribe(lang => {
      this.switchLanguage(lang);
    });
  }
  virtual_keyboard() {}
  switchLanguage(language) {
   this.translate.use(language);
  }
}
