import { Injectable, Component, OnInit } from '@angular/core';
import { KeyboardComponent } from './keyboard/keyboard.component';
import { HttpClient, HttpHeaders} from '@angular/common/http';
import { Router } from '@angular/router';
import { environment } from '../environments/environment';
import { Subject } from 'rxjs/subject';
@Injectable()
export class DataserviceService {
  private Lang$ = new Subject();
  langName: string;
  userData: any = [];
  webServiceBaseUrl: string = environment.wolWebServiceBaseUrl;
  constructor(private http: HttpClient, private router: Router) {
  }

  public getApplicationVersion() {
    return this.http.get('/wolmobile/applicationVersion');
  }

  public loginservice(userId, password) {
    return this.http.post(this.webServiceBaseUrl + '/userService/authenticateUser', {'userId': userId, 'encryptedPassword' : password, 'decodedPassword': 'true'}, {headers: new HttpHeaders()
                             .set('Content-Type', 'application/json').set('Accept', 'application/json')});
  }

  public locationmove(location, cargoid, empid, vpccode, user) {
    return this.http.post(this.webServiceBaseUrl + '/locationService/locationMoveRf', {'vpcCode': vpccode, 'vin': cargoid, 'location': location, 'employeeId': empid, 'user': user} , {headers: new HttpHeaders()
                             .set('Content-Type', 'application/json').set('Accept', 'application/json')});
  }

  public vinInquirySearch(vpccode, company, customer, cargoid, empid) {
    return this.http.post(this.webServiceBaseUrl + '/singleVinInquiryWebService/searchVinDetails', {'vpcCode': vpccode, 'userId': empid, 'company': company, 'vin': cargoid, 'customer': customer, 'dwFlag': false} , {headers: new HttpHeaders()
                             .set('Content-Type', 'application/json').set('Accept', 'application/json')});
  }
  public vinInquiryGridSearch(vpccode, company, customer, cargoid, empid, lifeLineNo) {
    return this.http.post(this.webServiceBaseUrl + '/singleVinInquiryWebService/gridVinDetails', {'vpcCode': vpccode, 'userId': empid, 'company': company, 'vin': cargoid, 'customer': customer, 'dwFlag': false, 'lifeNumber': lifeLineNo} , {headers: new HttpHeaders()
                             .set('Content-Type', 'application/json').set('Accept', 'application/json')});
  }


  public receive(location, cargoid, shipper, vpccode, userId, empId) {
    return this.http.post(this.webServiceBaseUrl + '/locationService/receiveUnitRf', {'vpcCode': vpccode, 'vin': cargoid, 'location': location, 'shipper': shipper, 'user': userId, 'employeeId': empId} , {headers: new HttpHeaders()
                             .set('Content-Type', 'application/json').set('Accept', 'application/json')});
  }

  public parkingTicket(userId, cargoid, customer, vpccode, documentType) {
    return this.http.post(this.webServiceBaseUrl + '/singleVinInquiryWebService/parkingTicketData', {'vpcCode': vpccode, 'vin': cargoid, 'userId': 'MULAF001', 'customer': customer, 'documentType': 'PARKING_TICKET_SILENT'} , {headers: new HttpHeaders()
                             .set('Content-Type', 'application/json').set('Accept', 'application/json')});
  }

  public fetchLoadInfo(carrier, vpccode, refCode) {
    return this.http.get(this.webServiceBaseUrl + '/shipmentService/shipmentFetchLoadRf/' + vpccode + '/' + carrier + '/' + refCode , {headers: new HttpHeaders()
                             .set('Content-Type', 'application/json').set('Accept', 'application/json')});
  }

  public yardExist(userId, cargoid, loadReference, vpccode, loadCarrier, loadNumber) {
    return this.http.post(this.webServiceBaseUrl + '/shipmentService/shipUnitRf', {'user': userId, 'vpcCode': vpccode, 'vin': cargoid, 'loadReference': loadReference, 'loadNumber': loadNumber, 'loadCarrier': loadCarrier, 'excOverride': true} , {headers: new HttpHeaders()
                             .set('Content-Type', 'application/json').set('Accept', 'application/json')});
  }

  public fetchCustomerForVIN(vpcCode, cargoid) {
    return this.http.get(this.webServiceBaseUrl + '/cargoInfoService/cargoInfo/' + vpcCode + '/' + cargoid , {headers: new HttpHeaders().set('Content-Type', 'application/json').set('Accept', 'application/json')});
  }

  /*check employee id*/
  public check_emplyee(vpccode, empid) {
    return this.http.get(this.webServiceBaseUrl + '/employeeService/employeeInfo/' + vpccode + '/' + empid, {headers: new HttpHeaders().set('Content-Type', 'application/json').set('Accept', 'application/json')});
  }
  /*check employee id*/

  /*check userid permission*/
  public ins_chkadd_permsion(userid, codeType) {
    return this.http.get(this.webServiceBaseUrl + '/accessoryService/addAccyOnLoad?codeType=ACC_INST_VIN&userId=' + userid, {headers: new HttpHeaders().set('Content-Type', 'application/json').set('Accept', 'application/json')});
  }
  /*check userid permission*/

  /*Add Accessory*/
  public add_accessory_installer(accCode, accinstaller, exludeFeetveh, resoncode, userId, vin, vpccode, customer ) {
      return this.http.post(this.webServiceBaseUrl + '/accessoryService/addAccessory', {'accCode': accCode, 'accInstaller': accinstaller, 'clearCargoId': false, 'codeType': 'ACC_INST_VIN', 'customer': customer, 'excludeFleetVeh': exludeFeetveh, 'reasonCode': resoncode, 'shipperAccy': '', 'shortCargoFlag': false, 'skipWorkOrderCheck': false, 'userId': userId, 'vin': vin, 'vpcCode': vpccode}, {headers: new HttpHeaders().set('Content-Type', 'application/json').set('Accept', 'application/json')});
  }
  /*Add Accessory*/

  public addcomp_accessory(accCode, accinstaller, exludeFeetveh, userId, vin, vpccode, additional_data, customer ) {
    return this.http.post(this.webServiceBaseUrl + '/accessoryService/checkForAccyAddComplete', {
  'codeType': 'ACC_INST',
  'customer': customer,
  'userId': userId,
  'vpcCode': vpccode,
  'excludeFleetVeh': exludeFeetveh,
  'installer': accinstaller,
  'vin': vin,
  'accessory': accCode,
  'additionalData': additional_data,
  'programCode': null,
  'addAccyFlag': true,
}, {headers: new HttpHeaders().set('Content-Type', 'application/json').set('Accept', 'application/json')});
  }
  public scanPart(vpcCode, customer, accy, workorderNo, lineNo, part) {
    return this.http.post(this.webServiceBaseUrl + '/accessoryService/scanAccyPart', {'vpc': vpcCode, 'customer': customer, 'accessory': accy, 'wrkOrdNo': workorderNo, 'lineItemNo': lineNo, 'partNo': part} , {headers: new HttpHeaders()
                             .set('Content-Type', 'application/json').set('Accept', 'application/json')});
  }
  public add_and_comp_acc(accCode, accinstaller, exludeFeetveh, userId, vin, vpccode, additional_data, customer ) {
    return this.http.post(this.webServiceBaseUrl + '/accessoryService/addCompleteAccessory', {
      'codeType': 'ACC_INST',
      'customer': customer,
      'userId': userId,
      'vpcCode': '098',
      'excludeFleetVeh': exludeFeetveh,
      'installer': accinstaller,
      'vin': vin,
      'accessory': accCode,
      'additionalData': additional_data,
      'programCode': null
    }, {headers: new HttpHeaders().set('Content-Type', 'application/json').set('Accept', 'application/json')});

  }

/*paperless complete*/
  public paperless_compacc(accCode, accinstaller, userId, vin, vpccode, additional_data, customer) {
        return this.http.post(this.webServiceBaseUrl + '/accessoryService/completeAccessorySingle', {
          'additionalData': additional_data,
          'programCode': null,
          'addAccyFlag': false,
          'vpcCode': vpccode,
          'vin': vin,
          'accessory': accCode,
          'installer': accinstaller,
          'userId': accinstaller,
          'customer': customer
        }, {headers: new HttpHeaders().set('Content-Type', 'application/json').set('Accept', 'application/json')});
  }

/*paperless complete*/
  public logout() {
    localStorage.clear();
    this.router.navigate(['/login']);
  }


  public status(status) {
      const audio = new Audio();
      audio.src = 'assets/beeb_tone/' + status + '.mp3';
      audio.load();
      audio.play();
    }

    public getValidCargoId(cargoId: string) {
      if (cargoId !== null) {
       if (cargoId.length > 17) {
         if (cargoId.charAt(0).toLowerCase() === 'i') {
            return cargoId.substring(1);
         } else {
           return cargoId.substring(0, 17);
          }
        }
        if (cargoId.length < 18) {
            return cargoId;
        }
        if (cargoId.substring(0, 3).toLocaleLowerCase() === 'KMH'.toLocaleLowerCase() || cargoId.substring(0, 3).toLocaleLowerCase() === '4S3'.toLocaleLowerCase() || cargoId.substring(0, 3).toLocaleLowerCase() === '4S4'.toLocaleLowerCase()) {
            return cargoId.substring(0, 17);
        }
      }
        return 'InvalidVIN';
  }



    /*check Qc or NonQc*/
  public check_qc_nonqc(vpccode, empid) {

    return this.http.get(this.webServiceBaseUrl + '/employeeService/employeeInfo/' + vpccode + '/' + empid, {headers: new HttpHeaders().set('Content-Type', 'application/json').set('Accept', 'application/json')});

  }
  /*check Qc or NonQc*/

  /*shop area services*/
  public shop_area_services(vpccode, shoparea) {
    return this.http.get(this.webServiceBaseUrl + '/accessoryService/validateShopArea/' + vpccode + '/' + shoparea, {headers: new HttpHeaders().set('Content-Type', 'application/octet-stream').set('Accept', 'application/octet-stream')});
  }
  /*shop area services*/

  public vin_services(vpccode, vinid) {
    return this.http.get(this.webServiceBaseUrl + '/cargoInfoService/workOrderInfoForVin/' + vpccode + '/' + vinid, {headers: new HttpHeaders().set('Content-Type', 'application/json').set('Accept', 'application/json')});
  }
  /*complete paper less*/

/* Tender */
  /*perfome_tender */
  public perfome_tender(location, cargo_id, vpccode, userid) {
     return this.http.post(this.webServiceBaseUrl + '/tenderService/tenderUnitRf', {'location': location, 'vin': cargo_id, 'vpcCode': vpccode, 'user': userid} , {headers: new HttpHeaders()
                             .set('Content-Type', 'application/json').set('Accept', 'application/json')});

  }
  // open work order
  public tenderOpenWorkOrder(vpccode, cargo_id) {
     return this.http.get(this.webServiceBaseUrl + '/cargoInfoService/openWorkOrderInfo/' + vpccode + '/' + cargo_id, {headers: new HttpHeaders().set('Content-Type', 'application/json').set('Accept', 'application/json')});
  }
  // openHoldInfo
  public tenderopenHoldInfo(vpccode, cargo_id) {
     return this.http.get(this.webServiceBaseUrl + '/cargoInfoService/openHoldInfo/' + vpccode + '/' + cargo_id, {headers: new HttpHeaders().set('Content-Type', 'application/json').set('Accept', 'application/json')});
  }

   // fetch customer
  public fetch_customer_ref(vpccode, customer) {
    return this.http.get(this.webServiceBaseUrl + '/documentPrintService/documentPrintFetchCustomerRf/'
    + vpccode + '/' + customer, {headers: new HttpHeaders().set('Content-Type', 'application/json').set('Accept', 'application/json')});
  }

  // document print
  public document_print_ws(vpccode, customer, vin, userid) {
    return this.http.post(this.webServiceBaseUrl + '/documentPrintService/documentPrintRf', {
      'vin': vin,
      'vpcCode': vpccode,
      'customer': customer,
      'userId': userid
    }, {headers: new HttpHeaders().set('Content-Type', 'application/json').set('Accept', 'application/json')});
  }

  // process history
  public fetch_process_history(vin, dwFlag, userId, vpcCode, customer, fromDashboard) {
    return this.http.post(this.webServiceBaseUrl + '/vinInquiryWebService/processHistory', {
      'vin': vin,
      'dwFlag': dwFlag,
      'vpcCode': vpcCode,
      'customer': customer,
      'userId': userId,
      'fromDashboard': fromDashboard
    }, {headers: new HttpHeaders().set('Content-Type', 'application/json').set('Accept', 'application/json')});


}

  // tender tenderCompleteAccessory
  public tenderCompleteAccessory(vpccode, vin, accessory, installer, user) {
    return this.http.post(this.webServiceBaseUrl + '/accessoryService/completeAccessoryRf', {'vpcCode': vpccode, 'vin': vin, 'accessory': accessory, 'installer': installer, 'userId': user} , {headers: new HttpHeaders()
                             .set('Content-Type', 'application/json').set('Accept', 'application/json')});

  }
  // hold Complete
  public tenderCompleteHold(vpccode, vin, holdList, user) {
     return this.http.post(this.webServiceBaseUrl + '/holdService/completeHoldRf', {'vpcCode': vpccode, 'vin': vin, 'holdCodes': holdList, 'user': user} , {headers: new HttpHeaders()
                             .set('Content-Type', 'application/json').set('Accept', 'application/json')});


  }
  public openDamageDetailInfo(vpccode, cargo_id) {
    return this.http.get(this.webServiceBaseUrl + '/cargoInfoService/openDamageDetailInfo/' + vpccode + '/' + cargo_id, {headers: new HttpHeaders().set('Content-Type', 'application/json').set('Accept', 'application/json')});
  }

  // override
  public overRide(location, vin, vpcCode, user, excOverride) {
    return this.http.post(this.webServiceBaseUrl + '/tenderService/tenderUnitRf', {'location': location, 'vin': vin, 'vpcCode': vpcCode, 'user': user, 'excOverride': excOverride}, {headers: new HttpHeaders().set('Content-Type', 'application/json').set('Accept', 'application/json')});
  }

  // Damage Complete
  public tenderCompleteDamage(vpccode, vin, inspectorCode, damageSource, sequence, area, type, severity, closureDate, lineItemNo, user) {
     return this.http.post(this.webServiceBaseUrl + '/damageService/completeDamageRf', {'vpcCode': vpccode, 'vin': vin, 'damageOutputDetails': [{'inspectorCode': inspectorCode, 'damageSource': damageSource, 'sequence': sequence, 'area': area, 'type': type, 'severity': severity, 'closureDate': closureDate, 'lineItemNo': lineItemNo }], 'user': user} , {headers: new HttpHeaders()
                             .set('Content-Type', 'application/json').set('Accept', 'application/json')});


  }
public validateAccyWithShopArea(vpcCode, customer, accessory, shopArea) {
  return this.http.post(this.webServiceBaseUrl + '/accessoryService/validateAccyWithShopArea', {
    'vpc' : vpcCode,
    'customer' : customer,
    'accessory' : accessory,
    'shopArea' : shopArea
  }, {headers: new HttpHeaders().set('Content-Type', 'application/json').set('Accept', 'application/json')});

}
public fetchPartDetails(vpcCode, customer, accessory) {
  return this.http.post(this.webServiceBaseUrl + '/accessoryService/fetchPartDetails', {
    'vpc' : vpcCode,
    'customer' : customer,
    'accessory' : accessory,
  }, {headers: new HttpHeaders().set('Content-Type', 'application/json').set('Accept', 'application/json')});

}
public scanPartForAddorDelete(vpcCode, customer, userId, partNo, altPart, isDelete) {
  return this.http.post(this.webServiceBaseUrl + '/accessoryService/scanAlternateParts', {
    'vpc': vpcCode,
    'customer': customer,
    'userId': userId,
    'partNo': partNo,
    'alternatePart': altPart,
    'deletePart': isDelete
  }, { headers: new HttpHeaders().set('Content-Type', 'application/json').set('Accept', 'application/json')});
}


  /*Lang Switch*/

getLanguage() {
  return this.Lang$;
}
updateLanguage(data: string) {
      this.langName = data;
      this.Lang$.next(data);
}
/*Lang Switch*/


/*Rail load Build */

// 1.Fetch Load Info
public fetchAndValidateOpenLoad(location, railcarno) {
  return this.http.get(this.webServiceBaseUrl + '/railLoadService/fetchAndValidateOpenLoad/' + railcarno + '/' + location , {headers: new HttpHeaders().set('Content-Type', 'application/json').set('Accept', 'application/json')});
}
/*Rail load Build */







/*Message Properties*/
  public getErrorCode() {
    return this.http.get('./assets/i18n/' + this.langName + '.json');
  }
}

