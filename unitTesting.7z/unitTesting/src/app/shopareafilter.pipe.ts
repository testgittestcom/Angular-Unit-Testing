import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'shopareafilter'
})
export class ShopareafilterPipe implements PipeTransform {
  transform(value: any, args?: any): any {
    const shoparea_Code = args[0].shopareacode;
   // alert(args[0].shopareacode);
    // let shoparea_Code = args[0].shopareacode;
    let filter_data = [];
    const shopfilter = [];
    if (args[1].qcflag) {
      value.forEach(element => {
        if (element.accyStatus == '') {
          filter_data.push(element);
        }
      });
      if (shoparea_Code) {
        filter_data.forEach(element => {
          filter_data = [];
           if (shoparea_Code.indexOf(element.shopArea) !== -1 || shoparea_Code.indexOf(element.shopArea2) !== -1) {
            shopfilter.push(element);
        }
         });
        return shopfilter;
      }
        return filter_data;
      } else {
      return value;
    }
  }
}
