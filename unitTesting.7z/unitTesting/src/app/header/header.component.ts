import { Component, OnInit, Directive, Input } from '@angular/core';
import {DomSanitizer} from '@angular/platform-browser';
import {MatIconRegistry} from '@angular/material';
import { DataserviceService } from '../dataservice.service';
import { KeyboardComponent } from '../keyboard/keyboard.component';
import { Router, ActivatedRoute, Params, NavigationEnd, RouterLinkActive} from '@angular/router';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})


export class HeaderComponent implements OnInit {
  userdata = JSON.parse(localStorage.getItem('user_details'));
  show_menu = false;
  constructor(public router: Router, iconRegistry: MatIconRegistry, sanitizer: DomSanitizer, public service: DataserviceService, public keyboard: KeyboardComponent) {
  		iconRegistry.addSvgIcon('logout-user',
        sanitizer.bypassSecurityTrustResourceUrl('assets/images/logout.svg'));
        iconRegistry.addSvgIcon('header-menu',
        sanitizer.bypassSecurityTrustResourceUrl('assets/images/menu_icon.svg'));
        iconRegistry.addSvgIcon('dial_pad',
        sanitizer.bypassSecurityTrustResourceUrl('assets/images/dial_pad.svg'));
        iconRegistry.addSvgIcon('site_logo',
        sanitizer.bypassSecurityTrustResourceUrl('assets/images/site_logo_white.svg'));
        iconRegistry.addSvgIcon('lineal-keyboard',
        sanitizer.bypassSecurityTrustResourceUrl('assets/images/lineal_keyboard.svg'));
	   }
  ngOnInit() {
    if (localStorage.getItem('user_details')) {
        this.userdata = JSON.parse(localStorage.getItem('user_details'));
        this.service.updateLanguage(this.userdata[3].lang);
    } else {
      this.router.navigate(['witsonline/spring/login']);
    }
  }

  header_menu() {
      this.show_menu = !this.show_menu;
  }



}
