import { async, fakeAsync, ComponentFixture, TestBed, inject} from '@angular/core/testing';
import { HttpClientTestingModule} from '@angular/common/http/testing';
import { MockBackend} from '@angular/http/testing';
import {Jsonp, BaseRequestOptions, XHRBackend} from '@angular/http';
import { RouterTestingModule } from '@angular/router/testing';
import { MatIconModule, MatInputModule } from '@angular/material';
import { MatKeyboardModule } from '@ngx-material-keyboard/core';
import { KeyboardComponent } from '../keyboard/keyboard.component';
import { LoginComponent, } from './login.component';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';
import { DataserviceService } from '../dataservice.service';
import {MatDialog, MatDialogModule} from '@angular/material';
import { DebugElement, NO_ERRORS_SCHEMA} from '@angular/core';
import { BrowserModule, By } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
fdescribe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let el: DebugElement;
  let service: DataserviceService;
  let backEnd: MockBackend;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [LoginComponent],
      schemas: [ NO_ERRORS_SCHEMA ],
      imports: [ BrowserAnimationsModule, FormsModule, MatIconModule, MatInputModule, MatKeyboardModule, MatDialogModule, ReactiveFormsModule, HttpClientTestingModule, RouterTestingModule],
      providers: [DataserviceService, MockBackend, KeyboardComponent, MatDialog, MatDialogModule, {
        provide: Jsonp,
        useFactory: (backend, options) => new Jsonp(backend, options),
        deps: [MockBackend, BaseRequestOptions]
      }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    component.ngOnInit();
    el = fixture.debugElement.query(By.css('.loginBtn'));
    backEnd = TestBed.get(MockBackend);
    service = TestBed.get(DataserviceService);
});



  it('login component is should be defined', () => {
    expect(component).toBeDefined();
  });

 it('form should be valid', () => {
    const login_username = component.loginform.controls['login_username'].setValue('admin');
    const login_password = component.loginform.controls['login_password'].setValue('123456');
    const login_empolyeeid = component.loginform.controls['login_empolyeeid'].setValue('emp01');
    expect(component.loginform.valid).toBeTruthy();
  });

  it('form should be invalid', () => {
    const login_username = component.loginform.controls['login_username'].setValue('');
    const login_password = component.loginform.controls['login_password'].setValue('');
    const login_empolyeeid = component.loginform.controls['login_empolyeeid'].setValue('');
    expect(component.loginform.invalid).toBeTruthy();
  });
  /*afterEach(function () {
  component.loginform.controls['login_username'].setValue('rflaf01');
    component.loginform.controls['login_password'].setValue('RFLAF01');
  component.loginform.controls['login_empolyeeid'].setValue('2163');

  });*/
  it('DATA SERVICE IS COLLECT THE DATA', async(() => {
    component.loginform.controls['login_username'].setValue('rflafsdf01');
    component.loginform.controls['login_password'].setValue('RFLAF01');
     component.loginform.controls['login_empolyeeid'].setValue('2163');
    expect(component.loginform.valid).toBeTruthy();
    component.loginformsubmit();

  }));
  it('Submitting Form Invalid', () => {
    component.loginform.controls['login_password'].setValue('');
    component.loginform.controls['login_empolyeeid'].setValue('');
    component.loginform.controls['login_password'].setValue('');
    component.loginformsubmit();
    expect(component.loginform.invalid).toBeTruthy();
  });
  it('should be created defined', inject([DataserviceService], (dataServcie: DataserviceService) => {
    expect(service).toBeTruthy();
    dataServcie.loginservice('rflaf01', 'RFLAF01').subscribe((data) => {
      expect(data['userId']).toEqual('RFLAF01aaa');
    });
  }));
  // it('EmployeeID not entered', () => {
  //   component.loginform.controls['login_username'].setValue('rflaf01');
  //    component.loginform.controls['login_empolyeeid'].setValue('2163');
  //   component.loginformsubmit();
  //   expect(component.loginform.invalid).toBeTruthy();
  // });



  // it('is submitted true', () => {
  //   expect(component.isSubmitted).not.toBeTruthy();
  // });
  // it('is submitted false', () => {
  //   expect(component.isSubmitted).toBeFalsy();
  // });

  // it('should construct service', async(inject([DataserviceService], (Dataservice) => {
  //   expect(Dataservice).toBeDefined();
  // })));

  // it('form is valid', () => {
  //   const element = fixture.debugElement;
  //   const compiled = element.nativeElement;
  //   const button = compiled.querySelector('.loginBtn');
  //   component.loginformsubmit();
  //   fixture.detectChanges();
  //   expect(component.loginform.valid).not.toEqual(true);
  // });

  // it('form is invalid', () => {
  //   const element = fixture.debugElement;
  //   const compiled = element.nativeElement;
  //   const button = compiled.querySelector('.loginBtn');
  //   component.loginformsubmit();
  //   fixture.detectChanges();
  //   expect(component.loginform.valid).toEqual(false);
  // });

  // it('login_empolyeeid is empty', () => {
  //   component.loginformsubmit();
  //   fixture.detectChanges();
  //   const login_empolyeeid = component.loginform.controls['login_empolyeeid'].setValue('emp01');
  //   expect(component.loginform.value.login_empolyeeid).toEqual(false);
  // });

  // it('loginservice check', () => {
  //   service.loginservice('rflaf01', 'RFLAF01').subscribe((data) => {
  //     expect(data.hasOwnProperty('userId')).toEqual(true);
  //   });
  // });
  // it('locationmove check', () => {
  //   service.locationmove('asd', 'asd', 'sd', 'sd', 'asd').subscribe((data) => {
  //     expect(data.hasOwnProperty('userId')).toEqual(true);
  //   });
  // });
  // it('should be checkForApplicationVersion', () => {
  //   fixture.detectChanges();
  //   component.ngOnInit();
  //   expect(component.checkForApplicationVersion()).toBeDefined();
  // });
  // it('should be check ApplicationVersion', () => {
  //   fixture.detectChanges();
  //   component.ngOnInit();
  //   component.checkForApplicationVersion();
  //   expect((<any>component).serverVersion).not.toEqual(false);
  // });
  // // it('should be check openDialog', () => {
  // //   expect(component.openDialog('error_txt', 'focus_id')).toBeDefined();
  // // });
  // it('should be check openDialog', () => {
  //   service.loginservice(component.loginform.value.login_username, component.loginform.value.login_password).subscribe(
  //     result => {
  //       expect(result).toBeTruthy();
  //     });
  // });



});
