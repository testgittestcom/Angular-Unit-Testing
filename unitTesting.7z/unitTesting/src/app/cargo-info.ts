export class CargoInfo {
    vin: string;
    route: string;
    destination: string;
    carrier: string;
    extColor: string;
    dealer: string;
    model: string;
    dueDate: string;
    receiveDate: string;
    allocatedDate: string;
    openHold: string;
    damagedDate: string;
    repairedDate: string;
    releasedDate: string;
}
