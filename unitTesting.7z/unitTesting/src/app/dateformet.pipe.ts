import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'dateformet'
})
export class DateformetPipe implements PipeTransform {

  transform(value: any, args?: any): any {

  	if (value) {
  		return value.split(' ')[0];
  	} else {
  		return '-';
  	}
  }

}

export class PlanedDataFormat implements PipeTransform {
	 transform(value: any, args?: any): any {
	 	return new Date(value.substring(0, 4), value.substring(4, 6), value.substring(6, 8));
	 }
}
