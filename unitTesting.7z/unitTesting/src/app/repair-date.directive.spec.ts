import { RepairDateDirective } from './repair-date.directive';

describe('RepairDateDirective', () => {
  it('should create an instance', () => {
    const directive = new RepairDateDirective(null);
    expect(directive).toBeTruthy();
  });
});
