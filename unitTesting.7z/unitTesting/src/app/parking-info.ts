export class ParkingInfo {
    vin: string;
    destination: string;
    outboundMarket: string;
    location: string;
    color: string;
    endItemModelCode: string;
    companyName: string;
    engineNumber: string;
    userId: string;
    labelDate: string;
    empNo: string;
    assignLocation: string;
    modelCode: string;


}
