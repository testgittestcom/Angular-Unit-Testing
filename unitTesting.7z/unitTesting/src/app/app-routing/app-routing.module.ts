import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from '../login/login.component';

const MAINMENU_ROUTES: Routes = [
    { path: '', redirectTo: 'login', pathMatch: 'full' },
    { path: 'login', component: LoginComponent, data: { state : 'login'} }
];
export const CONST_ROUTING = RouterModule.forRoot(MAINMENU_ROUTES, {  useHash: true});

