import { Component, OnInit, ElementRef, HostListener, Inject, Input, Output, AfterContentInit, ContentChild, AfterViewInit, ViewChild, ViewChildren, Renderer2} from '@angular/core';


import { FormGroup, FormControl, Validators, ReactiveFormsModule} from '@angular/forms';
import { Router, ActivatedRoute, Params, NavigationEnd} from '@angular/router';

import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { MatKeyboardModule, MatKeyboardService } from '@ngx-material-keyboard/core';

@Component({
 selector: 'app-dialog-box',
 template: `<div class="dialog_btn dialog_box">

 <div class="bg-white details_section valid_pass" *ngIf="data.status_head">
   <div class="details_pass">
     <div class="head">
       <ul class="list-inline p-0 mb-0">
         <li class="list-inline-item float-left"><mat-icon svgIcon="status_hold" class="status_mark right status_hold"></mat-icon>
         </li>
         <li class="list-inline-item pt-1">
            <p class="txt_label m-0 text-uppercase font-weight-bold" style="color:#000">{{data.status_title}}</p>
            <p class="txt_cargoid_green m-0 font-weight-bold">{{data.cargo_id}}</p>
            <p class="txt_label text_green m-0 text-uppercase font-weight-bold" style="color:#b1b2b6">{{data.status_msg}}</p>
          </li>
        </ul>
      </div>
    </div>
  </div>

<div class="dialog_main">
  <div mat-dialog-content class="text-center dialog_content">
   <span>{{data.error_txt}}</span>
  </div>
  <div mat-dialog-actions>
    <div class="row no-gutters w-100">
     <div class="col-6 pr-1 pl-0 m-auto" *ngIf="data.ok_btn">
       <div class="btn_radius">
           <button type="submit" (click)="yes_ok()"  mat-raised-button color="primary" class="text-uppercase w-100">{{data.ok_btn_txt}}</button>
         </div>
       </div>
       <div class="col-6 pl-1 pr-0 m-auto" *ngIf="data.cancel_btn">
         <div class="btn_radius  btn_outlayout">
           <button type="submit" (click)="no_cancel()" mat-raised-button color="primary" class="text-uppercase w-100">{{data.cancel_btn_txt}}</button>
         </div>
       </div>
     </div>
    </div>
  </div>
</div>`,

styles: [`
  .txt_label{font-size: 13px;
    line-height: 13px;}
   .txt_cargoid_green{
     color: #5A5E67;
    font-size: 20px;
    line-height: 24px;
   }
   .details_pass { border-bottom:1px solid #ddd;padding-left:10px;padding-right:15px;margin-bottom:10px;
   }
   .dialog_main{
     padding-left:10px;
     padding-right:15px;
   }
`]
})

export class DialogboxComponent implements OnInit {
constructor(
   public dialogRef: MatDialogRef<DialogboxComponent>,
      @Inject(MAT_DIALOG_DATA) public data: any ) {
    console.log(data);

  }
ngOnInit() {
}
 yes_ok(): void {
 	  this.dialogRef.close(true);
 }
 no_cancel(): void {
   this.dialogRef.close(false);
 }

}
