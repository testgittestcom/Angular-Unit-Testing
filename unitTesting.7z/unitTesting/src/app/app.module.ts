import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import {BrowserAnimationsModule, NoopAnimationsModule} from '@angular/platform-browser/animations';

import {MatDialogModule, MatButtonModule, MatCheckboxModule,
        MatInputModule, MatSelectModule, MatIconModule, MatChipsModule,
        MatSlideToggleModule, MatTabsModule, MatNativeDateModule } from '@angular/material';

import { MatFormFieldModule } from '@angular/material/form-field';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatDatepickerModule} from '@angular/material/datepicker';

/*Routing*/
import { CONST_ROUTING } from './app-routing/app-routing.module';
/*Routing*/

import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule  } from '@angular/forms';
import { AppComponent } from './app.component';
import { LoginComponent, DialogOverviewExampleDialogComponent  } from './login/login.component';

import { HeaderComponent } from './header/header.component';
import { DataserviceService } from './dataservice.service';
import { MatKeyboardModule, IKeyboardLayouts, keyboardLayouts, MAT_KEYBOARD_LAYOUTS,  } from '@ngx-material-keyboard/core';
import { KeyboardComponent } from './keyboard/keyboard.component';
import { DateformetPipe } from './dateformet.pipe';
import { HideKeyboardDirective } from './hide-keyboard.directive';
import { DialogboxComponent } from './dialog_box';
import { AutofocusDirective } from './focus.directive';
import { UpperCaseTextDirective } from './upperCase.directive';

import { ShopareafilterPipe } from './shopareafilter.pipe';

import { RepairDateDirective } from './repair-date.directive';


/*For Translate*/
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';

/*For Translate*/

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HeaderComponent,
    KeyboardComponent,
    DateformetPipe,
    DialogOverviewExampleDialogComponent,
    HideKeyboardDirective,
    AutofocusDirective,
    DialogboxComponent,
    UpperCaseTextDirective,
    ShopareafilterPipe,
    RepairDateDirective,
    DialogboxComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    HttpClientModule,

    CONST_ROUTING,

    NoopAnimationsModule,
    MatButtonModule,
    MatCheckboxModule,

    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatIconModule,
    MatChipsModule,
    MatSlideToggleModule,
   MatKeyboardModule,
   MatDialogModule,
   MatTabsModule,
   MatNativeDateModule,
   MatExpansionModule,
   MatDatepickerModule,
   TranslateModule.forRoot({
        loader: {
            provide: TranslateLoader,
            useFactory: (HttpLoaderFactory),
            deps: [HttpClient]
        }
    })
  ],
  entryComponents: [ DialogOverviewExampleDialogComponent, DialogboxComponent ],
  providers: [DataserviceService, KeyboardComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
export function HttpLoaderFactory(http: HttpClient) {
 return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}
