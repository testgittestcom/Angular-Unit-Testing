import { HideKeyboardDirective } from './hide-keyboard.directive';

describe('HideKeyboardDirective', () => {
  it('should create an instance', () => {
    const directive = new HideKeyboardDirective(null);
    expect(directive).toBeTruthy();
  });
});
