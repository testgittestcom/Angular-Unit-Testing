import { Directive, HostListener, Input } from '@angular/core';
import { KeyboardComponent } from './keyboard/keyboard.component';

@Directive({
  selector: '[appHideKeyboard]'
})
export class HideKeyboardDirective {

  constructor(private keyboard: KeyboardComponent) { }

  @HostListener('click', ['$event']) onTextClick(event: Event) {
    this.hideAndroidKeyboard();
  }

  @HostListener('focus', ['$event']) onTextFocus(event: Event) {
    this.hideAndroidKeyboard();
  }

  private hideAndroidKeyboard() {
    if (!this.keyboard.Vkeyboard) {
      if (typeof(android) !== 'undefined') {
        setTimeout(function() { android.hideKeyboard(); }, 100);
      }
    }
  }
}

interface WebAppInterface {
  showToast(toast: string): any;
  hideKeyboard(): any;
}
declare var android: WebAppInterface;
