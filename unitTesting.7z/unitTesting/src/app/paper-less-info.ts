export class PaperLessInfo {
	installer_id: string | number;
	shoparea: string;
	vin: string | number;
	partList?: string;
	additionalData?: [{}];
}
export class PaperLessAdditionalData {

}

