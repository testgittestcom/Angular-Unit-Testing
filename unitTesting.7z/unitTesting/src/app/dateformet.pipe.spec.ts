import { DateformetPipe } from './dateformet.pipe';

describe('DateformetPipe', () => {
  it('create an instance', () => {
    const pipe = new DateformetPipe();
    expect(pipe).toBeTruthy();
  });
});
